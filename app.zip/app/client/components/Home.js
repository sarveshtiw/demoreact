import {Router, Route, Link, browserHistory, IndexRoute } from 'react-router';
import React, { Component } from 'react';
import Header from "./Header";
import Login from "./Login";
import Signup from "./Signup";
import Footer from "./Footer";
import DashboardHeader from "./DashboardHeader";
import DashboardLeft from "./DashboardLeft";
import Middlearea from "./Middlearea";
import RightSidebar from "./RightSidebar";

class Home extends Component {

  render() {
    return (
      <div>
        <Header />

        <Login />

        <Signup />

        <Footer />
      </div>
    );
  }
}

export default Home;
