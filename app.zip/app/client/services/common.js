"use strict";

var Common = {
    connection: null,
    connected: false,
    
    connection: function() {      
        Common.connection = new Strophe.Connection("ws://192.168.100.235:5280/websocket"); 
        return Common.connection;
    },

    connect: function(jid, password){        
        return Common.connection.connect(jid, password); 
    },

    disconnect: function () {
        //Common.connection.flush();
        //Common.connection.disconnect();
        Common.connected = false;
    },

    onConnect: function(status) {

        if (status === Strophe.Status.CONNECTING) {
            Common.log('Strophe is connecting.');
        }
        else if (status === Strophe.Status.CONNFAIL) {
            Common.log('Strophe failed to connect.');
        }
        else if (status === Strophe.Status.DISCONNECTING) {
            Common.log('Strophe is disconnecting.');
        }
        else if (status === Strophe.Status.DISCONNECTED) {
            Common.log('Strophe is disconnected.');
        }
        else if (status === Strophe.Status.CONNECTED) {
            Common.log('Strophe is connected.');
            Common.connected = true;

            login(Common.connected);
        }
        
        return status;
    },

    log: function(msg){
        console.log(msg);
    }
};

export default Common;
