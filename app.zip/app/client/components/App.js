import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { getRoster, updateRosterFlag, activeRoster } from '../actions/roster';
import { getChatMessages, addMessage, incomingMessages } from '../actions/chat';
import { getRooms } from '../actions/muc';
import Main from './Main';

const mapStateToProps = (state) => ({
    rosterData: state.roster.all,
    clickedRoster: state.roster.active,
    chatData: state.chat.all,
    roomsData: state.muc.all,
})

const mapDispatchToProps = {
    getRoster,
    updateRosterFlag,
    activeRoster,
    getChatMessages,
    addMessage,
    incomingMessages,
    getRooms
}

export default connect(mapStateToProps, mapDispatchToProps)(Main)
