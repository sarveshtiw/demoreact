const rooms = {
  "conferences": [
    {
      'name': "India Group",
      'jid': {
        'bare': "india@conference.asergis.com",
        'local': "india"
      },
      'nick': "india conf",
      'autoJoin': true,
    },
    {
      'name': "Malta Group",
      'jid': {
        'bare': "malta@conference.asergis.com",
        'local': "malta"
      },
      'nick': "malta conf",
      'autoJoin': true,
    },
    {
      'name': "UK Group",
      'jid': {
        'bare': "ukgrp@conference.asergis.com",
        'local': "uk"
      },
      'nick': "uk conf",
      'autoJoin': true,
    }
  ]
};

export default rooms;
