import store from '../store';
import mucfilter from '../models/mucfilter';
import { LIST_MUC, ADD_MUC, REMOVE_MUC, UPDATE_MUC, ACTIVE_MUC } from '../constants';

export const getRooms = (values, data) => {
	//  console.log("val",values);

	return function (dispatch) {
		dispatch({
			type: LIST_MUC,
			payload: {
				newVal: values
			}
		})
	}
}
