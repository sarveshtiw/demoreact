$(document).ready(function(){

    new WOW().init();
    $('[data-toggle="tooltip"]').tooltip();
    /*
    $("#btn1").click(function(){
	    $("#signup_section").hide();
	    $("#login_section").hide();
	    $(".header_main").hide();
	    $(".footer_landing").hide();
	    $(".dashboard").show();

	});

	$("#btn2").click(function(){
	    $("#signup_section").show();
	    $("#login_section").hide();
	    $('#signup_section').css('display',block);
	    $('#login_section').css('display',none);
	});
	*/
	$(".person-online-toggle button").click(function(){
	    $(".toptoggler").hide();
	    $(".list-group.pull-right").show();
	    $("#demo").css("margin-top", "-60px");

	});

	$(".RightSidebar .person-online-toggle button").click(function(){
	    $(".toptoggler").show();
	    $(".list-group.pull-right").hide();
	    $("#demo").css("margin-top", "0px");
	});

	$('.popBtn1').popover({
	    placement: 'bottom',
	    html: true,
	    content: function () {
	        return $(this).next('.AddContacts').html();
	    }

	});

	$(".popBtn1").click(function(){
	    $(".popBtn1").toggleClass("closeBtn");
	});

  $('.popBtn2').popover({
	    placement: 'bottom',
	    html: true,
	    content: function () {
	        return $(this).next('.MeetingContacts').html();
	    }

	});

	$(".popBtn2").click(function(){
	    $(".popBtn2").toggleClass("closeBtn");
	});
	$('body').on('click', function (e) {
    //did not click a popover toggle or popover
    if ($(e.target).data('toggle') !== 'popover'
        && $(e.target).parents('.popover.in').length === 0) {
        $('[data-toggle="popover"]').popover('hide');
    	$(".popBtn1").removeClass("closeBtn");
	    }
	});
	$(".icon-Video-icon").click(function(){
	    $(".OneToOneVideoCall").show();
	    $(".WelcomeMessageView").hide();
	});



	/****************Contact chip*************/

  $('.chips-initial').material_chip({
    data: [{
      image: 'images/group-pic4.png',
      tag: 'Andy Samberg',
    }, {
      image: 'images/group-pic4.png',
      tag: 'Anton Starkman',
    }],
  });

	/****************Contact chip************/



	/******Materrial BUtton JS**************/
	$('.mdBtn').mousedown(function (e) {
	    var target = e.target;
	    var rect = target.getBoundingClientRect();
	    var ripple = target.querySelector('.ripple');
	    $(ripple).remove();
	    ripple = document.createElement('span');
	    ripple.className = 'ripple';
	    ripple.style.height = ripple.style.width = Math.max(rect.width, rect.height) + 'px';
	    target.appendChild(ripple);
	    var top = e.pageY - rect.top - ripple.offsetHeight / 2 -  document.body.scrollTop;
	    var left = e.pageX - rect.left - ripple.offsetWidth / 2 - document.body.scrollLeft;
	    ripple.style.top = top + 'px';
	    ripple.style.left = left + 'px';
	    return false;
	});
	/******Materrial BUtton JS**************/


});
