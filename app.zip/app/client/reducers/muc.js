import {
    LIST_MUC,
    ADD_MUC,
    REMOVE_MUC,
    UPDATE_MUC,
    ACTIVE_MUC,
} from '../actions/muc'

// reducer
const initialState = {all:{}, active:{}};


export default (state = initialState, action) => {

    switch(action.type){
        case 'LIST_MUC':{
            var messages = {
                ...state,
                all:[...state.all, action.payload.newVal]
            }
            return messages;
        }

        default:{
          return state
        }
  }
}
