/*global app, me, client*/

var _ = require('underscore');

module.exports = {

    fliterContacts: function (contacts, data) {
        var numContacts = Object.keys(contacts).length;
        if(numContacts == 0){
            //create new contact list
            _.each(data, function(item) {
                contacts.push({
                    jid: item.jid,
                    name: item.name ? item.name : item.jid.bare,
                    domain: item.jid.domain,
                    group: item.groups[0],
                });
            });

        }else{

            for( var k = 0; k < numContacts; k++ ) {

                for(var i=0; i < data.length; i++){
                    if(data[i][contacts[k]['jid'].bare] !== undefined){
                        contacts[k]['status'] = data[i][contacts[k]['jid'].bare]['status'];
                    }else{
                        //contacts[k]['status'] = 'unavailable';
                    }
                }

            }
        }

        //console.log('contacts', contacts);
        return contacts;
    },

    updateContacts(){

    },

    setContacts: function(contacts){

    }

};
