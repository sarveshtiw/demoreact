import {Router, Route, Link, browserHistory, IndexRoute } from 'react-router';
import React, { Component } from 'react';

{ /*Login section*/ }

class Signup extends Component {

  render(){
    return (
      <section id="signup_section" className="login_section signup_section">
          <div className="container">
            <div className="row">
              <div className="col-md-6 col-md-offset-1">
                  <div className="landing_text section--purple wow slideInLeft" data-wow-delay="1s">
                    <h1><span>Powering Every</span>Conversation</h1>
                    <h2>Asergis Web Conferencing</h2>
                    <p>lets you video call with up to 12 friends. Send text, picture, and video messages, whiteboarding and lots more. </p>
                    <button className="btn-default learn_more mdBtn">Learn More</button>
                  </div>
              </div>
              <div className="col-md-5 pull-right">
                  <form className="form-signin signup_form section--green wow slideInRight" data-wow-duration="1s">
                    <h2 className="form-signin-heading">Sign Up</h2>
                      <label>Your Name</label>
                      <div className="row">
                        <div className="col-md-6">
                          <input id="inputEmail" className="form-control" placeholder="First Name" required="" type="text"/>
                        </div>
                        <div className="col-md-6">
                          <input id="inputEmail" className="form-control" placeholder="Last Name" required="" type="text"/>
                        </div>
                      </div>
                       <label>Your Company Details</label>
                      <div className="row">
                        <div className="col-md-6">
                          <input id="inputEmail" className="form-control" placeholder="Company Name" required="" type="text"/>
                        </div>
                        <div className="col-md-6">
                          <input id="inputEmail" className="form-control" placeholder="Work No" required="" type="text"/>
                        </div>
                      </div>
                       <label>Email & Password</label>
                      <div className="row">
                        <div className="col-md-6">
                          <input id="inputEmail" className="form-control" placeholder="Email ID" required="" type="text"/>
                        </div>
                        <div className="col-md-6">
                          <input id="inputEmail" className="form-control" placeholder="Set Password" required="" type="password"/>
                        </div>
                      </div>
                      <label>Select Country</label>
                      <select className="selectpicker">
                        <option>United Kingdom</option>
                        <option>USA</option>
                        <option>Malta</option>
                        <option>India</option>
                      </select>
                      <p className="text-left">
                        <div className="checkbox checkbox-asergis checkbox-circle">
                          <input id="checkbox1" type="checkbox" checked="checked"/>
                          <label for="checkbox1">
                              I accept <a href="">Terms & Conditions</a> and <a href="">Privacy Policy</a>
                          </label>
                        </div>
                       </p>
                      <button id="btn2" className="btn btn-lg btn-primary btn-block" type="button">Get Started</button>
                      <p className="text-center login_here">Already have and acoount <a href="">Login here</a></p>
                  </form>
              </div>
            </div>
          </div>
        </section>
    )
  }
}

export default Signup;
