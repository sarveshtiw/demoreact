import {
    CHAT_HISTORY,
    CHAT_ADD,
    CHAT_REMOVE,
    CHAT_UPDATE,
} from '../actions/chat'

// reducer
const initialState = { all: {}, active: {} };


export default (state = initialState, action) => {
    
    switch (action.type) {

        case 'CHAT_OUTGOING': {
            const jid = (action.payload.newVal.from.channel ? action.payload.newVal.from.channel : action.payload.newVal.to.jid);
            const mid = action.payload.newVal.id;
            console.log('jid', action.payload.newVal)
            var messages = {
                ...state,
                all: {...state.all,
                    [jid]: {...state.all[jid], 
                        [mid]:action.payload.newVal
                    }
                }
            }

            return messages;
        }

        case 'CHAT_INCOMING': {
            const jid = (action.payload.newVal.from.channel ? action.payload.newVal.from.channel : action.payload.newVal.from.jid);
            const mid = action.payload.newVal.id;
            console.log('jid', action.payload.newVal)
            var messages = {
                ...state,
                all: {...state.all,
                    [jid]: {...state.all[jid], 
                        [mid]:action.payload.newVal
                    }
                }
            }

            return messages;
        }

        case 'CHAT_HISTORY': {
            return state;
        }

        default: {
            return state
        }
    }
}