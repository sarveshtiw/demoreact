import { Router, Route, Link, browserHistory, IndexRoute } from 'react-router';
import React, { Component } from 'react';

class RightSidebar extends Component {

	constructor(props) {
		super(props);
		this.updateChatSection = this.updateChatSection.bind(this);
	}

	updateChatSection(value) {
		//call action and assign this value to reducer
		this.props.activeRoster(value);
	}

	render() {
		const { rosterData } = this.props;
		return (
			<div className="col-md-3 RightSidebar">
				<div id="demo" className="collapse">
					<div className="toggle-inner">
						<div className="group_img">
							<img src="images/group-pic4.png" alt="" />
							<span className="online-person"></span>
						</div>
						<div className="person-online-toggle">
							<p>William Wordsworth</p>
							<p><span>Online</span></p>
							<button data-toggle="collapse" data-target="#demo"><img src="images/top-toggler-arrow-onclick.png" alt="" /></button>
						</div>
						<ul>
							<li className="ac_setting"><a href=""><span className="icon-ProfilesSetting-icon"></span> <span className="togleTxt">AC. Settings</span></a></li>
							<li className="ac_calendar"><a href=""><span className="icon-Calendar-icon"></span> <span className="togleTxt">Calendar</span></a></li>
							<li className="ac_activity"><a href=""><span className="icon-Calendar-icon"></span> <span className="togleTxt">Activity Log</span></a></li>
						</ul>
					</div>
				</div>
				<div className="MeetingRooms">

					<div className="MeetingRoom_Heading">
						<div className="RoomHeadeingLeft">
							<h4>Contacts</h4>
						</div>
						<a className="btn btn-default popBtn1" href="#" data-toggle="popover" data-placement="bottom">Add New</a>
						{/*Add Contact Popover Start*/}
						<div className="AddContacts hide">
							<h5>Invite your full team</h5>
							<form method="post" action="">
								<div className="chips chips-initial"></div>
								<div className="row">
									<div className="col-md-6">
										<label>Email</label>
										<input id="inputEmail" className="form-control" placeholder="Enter Email" required="" type="email" />
									</div>
									<div className="col-md-6">
										<label>Name (Optional)</label>
										<input id="inputEmail" className="form-control" placeholder="Enter Name" required="" type="text" />
									</div>
								</div>
								<p className="text-center"><span>OR</span></p>

								<div className="row">
									<div className="col-md-12">
										<div className="input-group file_upload">
											<input type="text" className="form-control" placeholder="No file uploaded yet" />
											<label className="input-group-btn">
												<span className="btn btn-primary">
													Browse <input type="file" multiple />
												</span>
											</label>
										</div>
										<span className="help-block">
											<span>Upload file in Excel format only</span>
											<span className="pull-right">Max file size 3MB</span>
										</span>
									</div>
								</div>

								<p>
									<a href="">Skip for now</a>
									<a href="" className="btn pull-right">Send invitation</a>
								</p>

							</form>
						</div>
						{/*Add Contact Popover End*/}
					</div>


					<ul className="MeetingContacts">
						{Object.keys(rosterData || {}).map((keyName, keyIndex) => {
							return (
								<li key={keyIndex}>
									<div className="group_img">
										<div className="no_img">{rosterData[keyName].name.substr(0, 1).toUpperCase()}</div>
										<span className={rosterData[keyName].status == 'available' ? 'onlineContact' : 'offlineContact'}></span>
									</div>
									<div className="groupRight">
										<div className="contLeft">
											<h5>{rosterData[keyName].name}</h5>
											<div className="group_member_online">
												<span className="designation">{rosterData[keyName].group}</span>
											</div>
										</div>
										<div className="contact_icons">
											<ul>
												<li className="chatIcon" onClick={() => this.updateChatSection(rosterData[keyName])}><span className="icon-Chat-icon"></span></li>
											</ul>
										</div>
									</div>
								</li>
							)
						})}
					</ul>
				</div>
			</div>
		)
	}
}

export default RightSidebar;
