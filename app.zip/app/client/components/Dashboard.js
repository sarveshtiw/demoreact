import {Router, Route, Link, browserHistory, IndexRoute } from 'react-router';
import React, { Component } from 'react';
import base64 from 'base-64';
import { connect } from 'react-redux';
import initapp from './../services/init';
import DashboardHeader from './DashboardHeader';
import DashboardLeft from './DashboardLeft';
import Middlearea from './Middlearea';
import RightSidebar from './RightSidebar';

import Contacts from '../models/contacts';

class Dashboard extends Component {

  constructor(props) {
        super(props);
        //console.log(props);
        this.state = {
            token: '1234567890',
            contacts:[],
            activeContact:null,
            rosterData:null
        };
    }

    componentWillUpdate () {
        //const { user } = this.props;
         //console.log("=====================",this.props);
    }

    componentWillMount(){
        //console.log(this.props.location.query);
        var params = this.props.location.query;
        var token = params.token.split("@asergis");
        var jid =  base64.decode(token[0]);

        localStorage.jid  = jid;//'sarvesh@asergis.com';
        localStorage.pass = '123456';
        initapp.launch();
    }

    componentDidMount() {
        const { getRoster, updateRosterFlag, activeRoster } = this.props;
        //console.log('------------',activeRoster);

        app.whenConnected(function(){
            console.log('connected');

            //if authentication failed
            client.on('auth:failed', function() {
                window.location = '/login';
            });

            //if client diactiveRostersconnected
            client.on('disconnected', function (err) {
                if (err) {
                    console.error(err);
                }
                if (!app.state.hasConnected) {
                    window.location = '/login';
                }
            });

            client.on('session:end', function (result) {
                console.info('daemon session ended, restarting');
                //setTimeout(function () {
                    //daemonPresence();
                //}, 10000);
                // callback(null, result);
            });

            //get contact listing
            client.getRoster(function (err, resp) {
                client.sendPresence();
                client.enableCarbons();

                if (resp.roster && resp.roster.items && resp.roster.items.length) {
                    getRoster(resp.roster.items);
                }
            });

            var keepalive;
            keepalive = JSON.parse(localStorage.keepalive || '{}');
            client.enableKeepAlive(keepalive);

            //get roster updates
            client.on('roster:update', function (iq) {
                var items = iq.roster.items;

                console.log('roster--update', items);
            });

            //get contacts availability status
            client.on('available', function(data){
                var values = [];
                values.push({
                    [data.from.bare]:{status:data.type},
                });
                //console.log('available', values);
                updateRosterFlag(values);
            });


            //send presence in every min
            //setInterval(function() {
                //client.sendPresence();
                //console.log('sending presence');
            //}, 60000);

        });
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.rosterData !== this.state.contacts) {
            //this.setState({ contacts: nextProps.rosterData });
        }
    }

    render() {

    return (
            <div>
                <div className="dashboard">
                    <DashboardHeader />
                    <section className="dashboard_aread">
                        <div className="container">
                            <div className="row">
                                <DashboardLeft
                                getRooms={this.props.getRooms}
                                roomsData={this.props.roomsData}
                                activeRoster={this.props.activeRoster}
                                />

                                <Middlearea
                                clickedRoster={this.props.clickedRoster}
                                getChatMessages={this.props.getChatMessages}
                                addMessage={this.props.addMessage}
                                incomingMessages={this.props.incomingMessages}
                                chatData={this.props.chatData}  />

                                <RightSidebar
                                rosterData={this.props.rosterData}
                                activeRoster={this.props.activeRoster} />
                            </div>
                        </div>
                    </section>
                </div>
            </div>
    	);
  	}
}

export default Dashboard;
