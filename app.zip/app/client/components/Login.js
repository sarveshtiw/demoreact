import {Router, Route, Link, browserHistory, IndexRoute } from 'react-router';
import React, { Component } from 'react';
import { connect } from 'react-redux';
//import { login } from '../actions/actions';
//import  Common from './../xmpp/common';

class Login extends Component {

  constructor(props) {
      super(props);

      this.state = {
          email: '',
          password: '',
          connected: false,
          loggedIn:this.props.loggedIn,
          shouldRedirect:this.props.shouldRedirect,
          token: '1234567890'
      };

      this.handleSubmit = this.handleSubmit.bind(this);
      this.handleChange = this.handleChange.bind(this);
      console.log("-------", this.props.token);
  }

  handleSubmit(e){
      e.preventDefault();

      var data = {
        email: this.state.email,
        password: this.state.password
      };

      this.props.login(data);
      //console.log("=====================",this.props);
  }

  componentWillUpdate () {

      //const { user } = this.props;
      //console.log("=====================",this.props);
  }
  componentWillMount(){
      //console.log("----------->>>>>",this.props.params.token);
  }
  componentDidMount() {
      console.log('====>>>',this.state.token);

      var config = {  jid: 'ravi@asergis.com',
                      password: '123456',
                      transport: 'websocket',
                      wsURL: 'ws://192.168.100.235:5280/websocket'
                  };

        if (!config) {
            console.log('missing config');
            //window.location = '/login';
        }

  }

  componentWillReceiveProps(nextProps) {

      if(nextProps.user.loggedIn === true){
          browserHistory.push('/dashboard');
      }
  }

  handleChange(e){
      this.setState({
        [e.target.name]: e.target.value
      });
  }

  render(){
    return (
      <section id="login_section" className="login_section">
        <div className="container">
          <div className="row">
            <div className="col-md-6 col-md-offset-1">
                <div className="landing_text section--purple wow slideInLeft" data-wow-delay="1s">
                  <h1><span>Powering Every</span>Conversation</h1>
                  <h2>Asergis Web Conferencing</h2>
                  <p>lets you video call with up to 12 friends. Send text, picture, and video messages, whiteboarding and lots more. </p>
                  <button className="btn-default learn_more mdBtn">Learn More</button>
                </div>
            </div>
            <div className="col-md-4 pull-right">
                <form className="form-signin section--green wow slideInRight" data-wow-duration="1s" onSubmit={this.handleSubmit} novalidate="true">
                  <h2 className="form-signin-heading">Log In</h2>
                    <label>Your Email</label>
                    <input id="inputEmail" name="email" onChange={this.handleChange} value={this.state.email}
                    className="form-control" placeholder="Email address" required="" type="email"/>

                    <label>Password</label>
                    <input id="inputPassword" name="password" onChange={this.handleChange} value={this.state.password}
                    className="form-control" placeholder="Password" required="" type="password"/>

                    <p className="text-right"><a href="">Forgot password? Reset here</a></p>
                    <button id="btn1" className="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
                    <p className="text-center"><span>OR</span></p>
                    <p className="text-left"><a href="">Don't have an account</a></p>
                    <button id="btn2" className="btn btn-lg btn-primary btn-block" type="button">Create New Account</button>
                    <p className="text-center linkedin_link"><a href="">Log in with Linkedin</a></p>
                </form>
            </div>
          </div>
        </div>
      </section>
    )
  }
}

const mapDispatchToProps = {
    //login
}

const mapStateToProps = (state) => ({
      //console.log("dsfsdf",state);
    user: state.user
})

export default connect(mapStateToProps, mapDispatchToProps)(Login)
