import { Router, Route, Link, browserHistory, IndexRoute } from 'react-router';
import React, { Component } from 'react';

class DashboardHeader extends Component {

	render() {
		return (
			<header className="header_dashboard">
				<div className="container">
					<div className="row">
						<div className="col-md-4">
							<a href="index.html" className="logo">
								<img src="images/logo-dashboard.png" alt="logo" />
							</a>
						</div>
						<div className="col-md-5 nopadding">
							<ul className="list-group pull-right">
								<li className="list-group-item">
									Turn off Notifications
                  					<div id="chekcustom" className="material-switch pull-right test">
										<input id="someSwitchOptionDefault" name="someSwitchOption001" type="checkbox" />
										<label htmlFor="someSwitchOptionDefault" className="label-default"></label>
									</div>
								</li>
							</ul>
						</div>
						<div className="col-md-3 pull-right nopadding">
							<div className="toptoggler">
								<div className="group_img">
									<img src="images/group-pic.png" alt="" />
									<span className="online-person"></span>
								</div>
								<div className="person-online-toggle">
									<p>{localStorage.jid}</p>
									<p><span>Online</span></p>
									<button data-toggle="collapse" data-target="#demo"><img src="images/top-toggler-arrow.png" alt="" /></button>
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
		)
	}
}
export default DashboardHeader;
