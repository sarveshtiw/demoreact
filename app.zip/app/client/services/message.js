var _ = require('underscore');

module.exports = {
    fetchHistory: function (data) {        
        var self = this;
        console.log(data.jid);
        //app.whenConnected(function () {
            var filter = {
                with: data.jid,
                rsm: {max: 20, before: true},
                complete: false
            };

            var a = client.searchHistory({
                with:'hasan@asergis.com',
                   rsm: {
                   max: 10,
                   before: true
                   }
                 }, function(err, res){
                     console.log('get messsss',res);
                 })

                 console.log('asaas',a);
           
            /*
            var lastMessage = self.messages.last();
            if (lastMessage && lastMessage.archivedId) {
                filter.rsm.after = lastMessage.archivedId;
            }

            if (self.lastHistoryFetch && !isNaN(self.lastHistoryFetch.valueOf())) {
                if (self.lastInteraction > self.lastHistemplatizertoryFetch) {
                    filter.start = self.lastInteraction;
                } else {
                    filter.start = self.lastHistoryFetch;
                }
            } else {
                filter.end = new Date(Date.now());
            }
            */
            client.searchHistory(filter, function (err, res) {
                return {};
                //console.log('=======', res.mamQuery.results);
                /*
                if (err) return;

                self.lastHistoryFetch = new Date(Date.now());

                var results = res.mamQuery.results || [];
                results.reverse();
                results.forEach(function (result) {
                    result = result.toJSON();
                    var msg = result.mam.forwarded.message;

                    msg.mid = msg.id;
                    delete msg.id;

                    if (!msg.delay) {
                        msg.delay = result.mam.forwarded.delay;
                    }

                    if (msg.replace) {
                        var original = Message.idLookup(msg.from[msg.type == 'groupchat' ? 'full' : 'bare'], msg.replace);
                        // Drop the message if editing a previous, but
                        // keep it if it didn't actually change an
                        // existing message.
                        if (original && original.correct(msg)) return;
                    }

                    msg.archivedId = result.mam.id;
                    msg.acked = true;

                    console.log('message history=====',msg);
                    //self.addMessage(msg, false);
                });
                */
            });

            
        //});
    },
    
};