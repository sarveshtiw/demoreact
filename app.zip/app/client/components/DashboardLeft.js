import { Router, Route, Link, browserHistory, IndexRoute } from 'react-router';
import React, { Component } from 'react';
import initapp from './../services/init';
import Modal from './Modal';
import rooms from '../data/rooms';
//import Select from 'react-select';

class DashboardLeft extends Component {

	constructor(props) {
		super(props);
		this.state = { mucLists: '', isPoppedOut: false, isOpen: false };
		this.addNewGroupClick = this.addNewGroupClick.bind(this);
		this.saveNewGroup = this.saveNewGroup.bind(this);
		/*this.toggleModal = this.toggleModal.bind(this);
		this.updateChatSection = this.updateChatSection.bind(this);*/
	}

	componentWillMount() {
		this.setState({
			mucLists: rooms
		});
	}

	componentDidMount() {
		let conf = rooms.conferences;
		app.whenConnected(function () {
			Object.keys(conf || {}).map((keyName, keyIndex) => {
				client.joinRoom(conf[keyIndex].jid.bare, localStorage.jid);
			});

			//get the members information
			client.getRoomMembers('india@conference.asergis.com', { items: [ { affiliation: 'owner' } ] },
				function (err, res) {
					console.log('members', err, res);
				});

				var opts =[{to:"hasan@asergis.com"}]
				var response = client.invite("india@conference.asergis.com",opts)
				console.log("invite",response);
		});

	}

	updateChatSection(value) {
		//call action and assign this value to reducer
		this.props.activeRoster(value);
	}

	toggleModal() {
		this.setState({
			isOpen: !this.state.isOpen
		});
	}

	addNewGroupClick() {

			this.setState({isOpen: true});
			alert("add");
	}

	saveNewGroup() {

	}



	render() {
		const mucList = this.state.mucLists.conferences;

		return (
			<div className="col-md-3 LeftSidebar" id="scrollbox3">
				<div className="input-group stylish-input-group">
					<span className="input-group-addon">
						<button type="submit">
							<span className="glyphicon glyphicon-search"></span>
						</button>
					</span>
					<input type="search" className="form-control" placeholder="Search Contact, Message, Files" />
				</div>
				<div className="MeetingRooms">
					<div className="MeetingRoom_Heading">
						<div className="RoomHeadeingLeft">
							<h4>Meeting Rooms</h4>
						</div>
						<a className="btn btn-default popBtn2" data-placement="bottom" onClick={this.addNewGroupClick} role="button">Add New</a>
						{/*Add Contact Popover Start*/}

						<div className="MeetingContacts hide">
							<h5>Invite your team</h5>

								<div className="row">
										<div className="col-md-12">
											  <label>Public</label>
			                  <div id="chkTogglecustom" className="material-switch test">
													<input id="someSwitchOptionDefault" name="someSwitchOption001" type="checkbox" />
													<label htmlFor="someSwitchOptionDefault" className="label-default"></label>
												</div>
										</div>

										<div className="col-md-12">
											<label>Name</label>
											<input id="group_name" className="form-control" placeholder="Enter Name" required="" type="text" />
										</div>

										<div className="col-md-12">
											<label>Purpose (Optional)</label>
											<input id="group_purpose" className="form-control" placeholder="Enter Purpose" required="" type="text" />
										</div>

										<div className="col-md-12">
											<label>Send invite to: (Optional)</label>
											<select className="form-control" name="contacts" id="contacts" multiple placeholder="Search your contacts" >
												<option value = "1"> Sarvesh@asergis.com </option>
												<option value = "2"> Ravion@asergis.com </option>
												<option value = "3"> Hasan@asergis.com </option>
												<option value = "4"> Vova@asergis.com </option>
												<option value = "5"> Marko@asergis.com </option>
												<option value = "6"> Indiagrp@asergis.com </option>
										  </select>
										</div>
								</div>
								<br />
								<p>
									<button onClick="" id="ttttt" className="btn pull-right">Send invitation</button>
									<a className="btn btn-default popBtn2" data-placement="bottom" href="javascript:void(0);" onClick={this.saveNewGroup} role="button">Add New</a>
									</p>

						</div>
						{/*Add Contact Popover End*/}

						<Modal show={this.state.isOpen}
							onClose={this.toggleModal}>
							<h1> Add New Group </h1>
							<hr />

							<input type="text" name="roomJID" id="roomJID" />
							<button onClick={this.addNewGroupClick}>
								Add
        			</button>
						</Modal>
					</div>
					<ul className="MeetingContacts">

						{Object.keys(mucList || {}).map((keyName, keyIndex) => {
							return (
								<li key={keyIndex}>
									<div className="group_img">
										<img src="images/no-pic.png" alt="" />
									</div>
									<div className="groupRight">
										<h5 onClick={() => this.updateChatSection(mucList[keyName])}><span><img src="images/favourite-icon.png" alt="" /></span>{mucList[keyName].name}</h5>
										<div className="group_member_online">
											<a className="btn btn-default grp-mem-btn" href="#" role="button"></a>
											<span className="loginTime"></span>
										</div>
									</div>
								</li>
							)
						})}

					</ul>
				</div>
			</div>
		)
	}
}
export default DashboardLeft;
