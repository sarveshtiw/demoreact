import { combineReducers } from 'redux';
import { routerReducer } from 'react-router-redux';

import roster from './roster';
import chat from './chat';
import muc from './muc';

const rootReducer = combineReducers({
    roster, chat, muc, routing: routerReducer 
});

export default rootReducer;
