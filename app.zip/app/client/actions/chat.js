import modelmessage from './../models/messagefilter';
import message from './../services/message';
import store from '../store';
import { CHAT_HISTORY, CHAT_OUTGOING, CHAT_INCOMING, CHAT_REMOVE, CHAT_UPDATE } from '../constants';

export const getChatMessages = (data) => {
	return function(dispatch){
		var chat = {};
		//chat = message.fetchHistory(data);

		dispatch({
			type: CHAT_HISTORY,
			payload: {
				newVal: chat
			}}
		)
  	}
}

export const addMessage = (values) => {
	var msgid = client.sendMessage(values);
	var messages = Object.assign(values, {msgid:msgid});
	console.log('asas', messages);
	var messagesarr = modelmessage.arrangeOutgoingMsg(messages);
	if(msgid){
		return function(dispatch){
			dispatch({
				type: CHAT_OUTGOING,
				payload: {
					newVal: messagesarr
				}}
			)
		}
	}
}

export const incomingMessages = (values) => {
	var messagesarr = modelmessage.arrangeIncominingMsg(values);

	return function(dispatch){
		dispatch({
			type: CHAT_INCOMING,
			payload: {
				newVal: messagesarr
			}}
		)
	}
}
