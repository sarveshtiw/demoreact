/*global $, app, me, client*/
var StanzaIO = require('stanza.io');
//import xmppEventHandlers from './xmppEventHandlers';

module.exports = {
    launch: function () {
        var self = window.app = this;
        var self = this;

        var config = {  
            jid: localStorage.jid,
            password: localStorage.pass,
            transport: 'websocket',
            wsURL: 'ws://192.168.100.235:5280/websocket'
        };

        if (!config) {
            console.log('missing config');
            window.location = '/login';
        }

        //initialise stanza client    
        self.api = window.client = StanzaIO.createClient(config);
        //xmppEventHandlers(self.api, self);

        self.api.once('session:started', function () {
            self.sessionStarted = true;
        });
        self.api.connect();
    },
    whenConnected: function (func) {
        if (self.sessionStarted) {
            func();
        } else {
            app.api.once('session:started', func);
        }
    },
    navigate: function (page) {
        var url = (page.charAt(0) === '/') ? page.slice(1) : page;
        app.state.markActive();
        app.history.navigate(url, true);
    },
    renderPage: function (view, animation) {
        //var container = $('#pages');

        //if (app.currentPage) {
        //    app.currentPage.hide(animation);
        //}
        // we call render, but if animation is none, we want to tell the view
        // to start with the active class already before appending to DOM.
        //container.append(view.render(animation === 'none').el);
        //view.show(animation);
    }
};