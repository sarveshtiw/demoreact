import { Router, Route, Link, browserHistory, IndexRoute } from 'react-router';
import React, { Component } from 'react';
import initapp from './../services/init';
import message from './../services/message';

class Middlearea extends Component {

	constructor(props) {
		super(props);
		//console.log(props);
		this.state = {
			clickedRoster: null,
			message: ''
		};

		this.handleSubmit = this.handleSubmit.bind(this);
		this.handleChange = this.handleChange.bind(this);
	}

	handleSubmit(e) {
		e.preventDefault();

		var message = {
			id: client.nextId(),
			to: this.props.clickedRoster.jid.bare,
			toname: this.props.clickedRoster.name ? this.props.clickedRoster.name : '',
			from: client.jid.bare,
			fromname: client.jid.bare,
			type: this.props.clickedRoster.hasOwnProperty('autoJoin') ? 'groupchat' : 'chat',
			body: this.state.message,
			requestReceipt: true,
			//oobURIs: links
		};

		this.setState({ message: '' });
		this.props.addMessage(message, 'sent');
	}

	handleChange(e) {
		this.setState({
			[e.target.name]: e.target.value
		});
	}

	componentDidMount() {
		const { addMessage, incomingMessages, chatData } = this.props;

		app.whenConnected(function () {
			//listners for getting chat messages
			client.on('chat', function (msg) {
				console.log('one2onemsg', msg);
				incomingMessages(msg);
			});

			//listners for getting groupchat messages
			client.on('groupchat', function (msg) {
				console.log('groupmsg', msg);
				if (msg.from.resource !== localStorage.jid) {
					incomingMessages(msg);
				}
			});

		});

		//get chat hostory
		//message.fetchHistory();
	}

	componentWillReceiveProps(nextProps) {
		var self = this;
		if (nextProps.clickedRoster !== this.props.clickedRoster) {
			this.props.getChatMessages(nextProps.clickedRoster);
		}

	}

	render() {
		const { clickedRoster, chatData } = this.props;
		//console.log('-----', clickedRoster);
		let sender = clickedRoster != null ? clickedRoster.jid.bare : '';
		let chatArray = chatData.hasOwnProperty(sender) ? chatData[sender] : {};
		//console.log('chatdata', chatArray);

		return (
			<div className="col-md-6 WelcomeMessageView">
				<div className="AppMiddleArea">
					<div className="MeetingRoom_Heading">
						<div className="RoomHeadeingLeft">
							<img src="images/asergis-bot-logo.png" alt="" /> <span>{clickedRoster ? clickedRoster.name : 'NA'}</span>
						</div>
						<ul className="chatfeature">
							{/*
							<li className="audioBtn"><span className="icon-ComingCall-icon"></span></li>
							<li className="SharescreenBtn"><span className="icon-PC-icon"></span></li>
							<li className="WhiteBoardBtn"><span className="icon-Art-icon"></span></li>
							<li className="AddMemBtn"><span className="icon-ProfilePlus-icon"></span></li>
							<li className="FullScreenBtn"><span className="icon-FullSize-icon"></span></li>
							*/}
						</ul>
					</div>
					<div className="ChatDisplayBox">
						<div className="WelcomeMsgDate">
							<span>Today</span>
						</div>

						<div className="SelfMsgView">
							{
								Object.keys(chatArray || {}).map((keyName, keyIndex) => {
									//console.log('body', chatArray[keyName].body);
									var mymsg = chatArray[keyName].from.jid == client.jid.bare ? 1 : 0;
									return(
										<div className={mymsg ? 'SelfMsgViewInner' : 'RemoteMsgViewInner'}  key={keyIndex}>
											<div className="media">
												{ mymsg ?
													<div className="media-left media-top">
														<div className="no_img_chat">{ chatArray[keyName].from.jid.substr(0, 1).toUpperCase() }</div>
													</div>
													: ''
												}
												<div className="media-body">
													<p><span>{chatArray[keyName].body}</span></p>
													<span className="SelMsgTime">{ new Date(chatArray[keyName].time).toLocaleString() }</span>
												</div>
												{ mymsg ? '' :
													<div className="media-right media-top">
														<div className="no_img_chat">{ chatArray[keyName].from.jid.substr(0, 1).toUpperCase() }</div>
													</div>
												}
											</div>
										</div>
									)
								})
							}
							<div className="MessageTyping">
								<div className="media">
									<div className="media-left media-top">
										<a href="#">
											<img className="media-object img-circle" src="images/typing-user-img.png" alt="" />
										</a>
									</div>
									<div className="media-body">
										<p><span><img src="images/typing.gif" alt="" /></span></p>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div className="ChatBar">
						<form name="chat" id="chat" method="post" onSubmit={this.handleSubmit}>
							<input type="text" name="message" onChange={this.handleChange} value={this.state.message} placeholder="Type your message..." required />
							<ul>
								<li className="attachfileBtn"></li>
								<li className="smileyBtn"></li>
								<li><input className="chatsubmitBtn" type="Submit" /></li>
							</ul>
						</form>
					</div>
				</div>
			</div>
		)
	}
}
export default Middlearea;
