import { Router, Route, Link, browserHistory, IndexRoute } from 'react-router';
import React, { Component } from 'react';

{ /*Login page header*/ }

class Header extends Component {

	render() {
		return (
			<header className="header_main">
				<div className="container">
					<div className="row">
						<div className="col-md-4">
							<a href="/" className="logo">
								<img src="images/logo.png" alt="logo" />
							</a>
						</div>
						<div className="col-md-4 pull-right">
							<ul className="nav navbar-nav pull-right">
								<li><a href="#">About</a></li>
								<li><a href="#">FAQ</a></li>
								<li className="btn-default"><a href="#">Login / Signup</a></li>
							</ul>
						</div>
					</div>
				</div>
			</header>
		)
	}
}

export default Header;
