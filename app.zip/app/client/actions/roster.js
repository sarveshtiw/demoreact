import Contacts from '../models/contacts';
import store from '../store';
import { LIST_CONTACT, ADD_CONTACT, REMOVE_CONTACT, UPDATE_CONTACT, ACTIVE_CONTACT } from '../constants';

export const getRoster = (data) => {
	return function(dispatch){
		var contacts = [];
		contacts = Contacts.fliterContacts(contacts, data);
		dispatch({
			type: LIST_CONTACT,
			payload: {
				newVal: contacts
			}}
		)
  	}
}

export const updateRosterFlag = (values) => {
    return function(dispatch){
		var oldContacts = store.getState().roster.all;
		if(oldContacts){
			var contacts = Contacts.fliterContacts(oldContacts, values);
			dispatch({
				type: UPDATE_CONTACT,
				payload: {
					newVal: contacts
				}}
			)
		}
    }
}

export const activeRoster = (values) => {
    return function(dispatch){
		dispatch({
			type: ACTIVE_CONTACT,
			payload: {
				newVal: values
			}}
		)
    }
}
