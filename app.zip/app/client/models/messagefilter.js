/*global app, me, client*/

var _ = require('underscore');

module.exports = {

    arrangeIncominingMsg: function (data) {
        //create new contact list
        var messages = [];
        
        var fromname = data.from.name !== undefined ? data.from.name : '';
        var toname  = data.to.name !== undefined ? data.to.name : '';
        var fromchannel = data.from.bare !== undefined ? data.to.name : '';
        
        let userjid = data.type == 'chat' ? data.from.bare : data.from.resource;
        messages = {
            body: data.body,
            from: {name:fromname, jid:userjid, channel:data.from.bare},
            to: {name:toname, jid:data.to.bare},
            type: data.type,
            id: data.id,
            time:new Date()
        };    

        //console.log('==@@@@====', messages);
        return messages;
    },

    arrangeOutgoingMsg: function (data) {
        //create new contact list
        var messagesarr = [];
        var fromname = data.fromname;
        var toname = data.toname;

        messagesarr = {
            body: data.body,
            from: {name:fromname, jid:data.from},
            to: {name:toname, jid:data.to},
            type: data.type,
            id: data.msgid,
            time:new Date()
        };    

        //console.log('==@@@@====', messagesarr);
        return messagesarr;
    },

    updateContacts(){

    },

    setContacts: function(contacts){

    }

};