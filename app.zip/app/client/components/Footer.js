import {Router, Route, Link, browserHistory, IndexRoute } from 'react-router';
import React, { Component } from 'react';

{ /*Login section*/ }

class Footer extends Component {
  
  render(){
    return (
      <footer className="footer_landing">
          <div className="container">
            <div className="row">
              <div className="col-md-4">
                <div className="landing_footer1 wow fadeInUp" data-wow-duration="3s">
                  <a href=""><img src="images/logo_footer.png" alt=""/></a>
                  <p>Web RTC Application which is an API definition that supports browser-to-browser applications for voice calling, video chat, and file sharing without the need of either internal or external plug-ins.</p>
                </div>
              </div>
              <div className="col-md-4">
                <div className="landing_footer2 wow fadeInUp" data-wow-duration="3s">
                  <h3>Our 10 major features</h3>
                  <ul>
                    <li><a href="#">Account Creation</a></li>
                    <li><a href="#">Recording</a></li>
                    <li><a href="#">Video Conference Call</a></li>
                    <li><a href="#">White Boarding</a></li>
                    <li><a href="#">Audio Calls</a></li>
                    <li><a href="#">File Sharing</a></li>
                    <li><a href="#">Instant Messaging</a></li>
                    <li><a href="#">Global Search</a></li>
                    <li><a href="#">Screen Sharing</a></li>
                    <li><a href="#">Calendar</a></li>
                  </ul>
                </div>
              </div>
              <div className="col-md-4">
                <div className="landing_footer3 wow fadeInUp" data-wow-duration="3s">
                  <ul>
                    <li><a href="#"><i className="fa fa-facebook-square"></i></a></li>
                    <li><a href="#"><i className="fa fa-twitter-square"></i></a></li>
                    <li><a href="#"><i className="fa fa-google-plus-square"></i></a></li>
                    <li><a href="#"><i className="fa fa-linkedin-square"></i></a></li>
                    <li><a href="#"><i className="fa fa-youtube-square"></i></a></li>
                  </ul>
                  <h3>Stay Updated</h3>
                  <p>Be the first to know about improvements in appear.in!</p>
                  <div className="input-group">
                    <input type="text" className="form-control" placeholder=""/>
                    <span className="input-group-btn">
                      <button className="btn btn-secondary" type="button">Submit</button>
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <div className="row">
              <hr/>
            </div>
            <div className="row">
              <div className="col-md-7">
                <p className="copyright_text">© Copyright Asergis Group 2001 - 2016. All Rights Reserved</p>
              </div>
              <div className="col-md-5 pull-right">
                <ul className="footer_menu">
                  <li><a href="#">Contact</a></li>
                  <li><a href="#">Legal Information</a></li>
                  <li><a href="#">Privacy Policy</a></li>
                  <li><a href="#">Terms of use</a></li>
                </ul>
              </div>
            </div>
          </div>
        </footer>
    )
  }
}

export default Footer;
