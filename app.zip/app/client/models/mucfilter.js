
var _ = require('underscore');

module.exports = {

    fliterRooms: function (rooms) {
        var totalRooms = Object.keys(rooms).length;
        //console.log("totalRooms",totalRooms);
        var roomLists = {};
        if(totalRooms > 0)
        {
            // used for new rooms array lists
            _.each(rooms, function(item) {
                roomLists.push({
                    jid: item.jid.bare,
                    name: item.name ? item.name : item.jid.local,
                    domain: item.jid.domain,
                    nick: item.nick,
                    autoJoin: item.autoJoin,
                });
            });
        }
        /*else
        {
            for(var outerCount = 0; outerCount < totalRooms; outerCount++) {
                for(var innerCount = 0; innerCount < data.length; innerCount++) {
                    if(data[i][rooms[outerCount]['jid']] !== undefined){
                        rooms[outerCount]['status'] = data[innerCount][rooms[innerCount]['jid']]['status'];
                    }
                }rooms

            }
        }*/
      return roomLists;
    },

};
