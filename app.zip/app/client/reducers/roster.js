import {
    LIST_CONTACT,
    ADD_CONTACT,
    REMOVE_CONTACT,
    ACTIVE_CONTACT
  } from '../actions/roster'

  // reducer
const initialState = {all:null, active:null};


export default (state = initialState, action) => {

    switch(action.type){
        case 'LIST_CONTACT':{
            var contacts = Object.assign({}, state, {
                all: action.payload.newVal,
                active: action.payload.newVal[0]
            });
            return contacts;
        }
        /*
        case 'ADD_CONTACT':{
            return Object.assign({}, state, action.payload.newVal)
        }

        case 'REMOVE_CONTACT':{
            return Object.assign({}, state, action.payload.newVal)
        }
        */
        case 'UPDATE_CONTACT':{
            var contacts = Object.assign({}, state, {
                all: action.payload.newVal,
                //active: action.payload.newVal[0]
            });
            return contacts;
        }

        case 'ACTIVE_CONTACT':{
            return Object.assign({}, state, {active:action.payload.newVal})
        }

        default:{
            return state
        }
    }
}
